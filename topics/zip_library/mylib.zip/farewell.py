def bye(name: str):
    print(f"Bye {name}")

